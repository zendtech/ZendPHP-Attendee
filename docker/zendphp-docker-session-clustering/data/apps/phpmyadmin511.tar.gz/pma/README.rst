phpMyAdmin for Composer
=======================

This is automatically generated repository to allow installation of phpMyAdmin
using composer.

You can find phpMyAdmin repository here:

https://github.com/phpmyadmin/phpmyadmin/

This repository is updated daily.
