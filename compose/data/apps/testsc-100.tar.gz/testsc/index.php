<?php
// COPY FROM STUDIO PROJECT "Zend Server API Tests"

// TODO Add checkbox to toggle time measurement (URL?time)
// TODO Add button to reset session - clear session and redirect to self
// TODO Add button to regenerate session ID - regenerate and redirect to self
// TODO Add Tabs to log output - Translated (first), Original (second)

//## Session Name ##//
if ( isset($_GET['name']) && $_GET['name'] != "") {
	session_name($_GET['name']);
} // if name

//## Session Domain ##//
// Coming after Session Name modification - see php.net for user reports
if ( isset($_GET['domain']) && $_GET['domain'] != "") {
	session_set_cookie_params(0,'/',$_GET['domain']);
} //if domain

//## SESSION START ##//
$time_start = microtime(true);
session_start();
//usleep(500000); // test timer with additional 0.5 sec delay
$time_end = microtime(true);
$time_seconds = $time_end - $time_start;

if (isset($_GET['reset'])) {
	//  session_commit();
	session_destroy();
	session_start();
}

if (isset($_GET['gen'])) {
	session_regenerate_id();
}

//ini_set("display_errors", 1);
//$error_level = ( version_compare(PHP_VERSION, 5, '>=') && version_compare(PHP_VERSION, 6, '<') ) ? "E_ALL ^ E_STRICT" : "E_ALL";
//error_reporting($error_level);
//error_reporting("E_ALL");

//echo "<h1>Session test script</h1>\n";

echo "<!DOCTYPE html>\n<html>\n<head><title>Session Clustering Test Script</title></head>\n<body>";

echo "<p>";
echo "<div style='float: left'><em><strong><a href='" . basename(__FILE__) . "'>Reload page without additional parameters</a></strong></em></div>\n";
echo "<div style='float: right'><strong><a href='lock.php' style='color: #a70'>Session Locking Test</a></strong></div>\n";
echo "<br><i>Additional parameters:</i><ul>\n";
echo "<li><strong><a href='?reset'>?reset</a></strong> - start a new session and clean collected data</li>\n";
echo "<li><strong><a href='?gen'>?gen</a></strong> - to regenerate Session ID and continue to collect data</li>\n";
echo "<li><strong><a href='?time'>?time</a></strong> - to measure session_start() timing in case of a busy network</li>\n";
echo "<li>Add ?name=<NAME> to the URL to use alternative name instead of PHPSESSID</li>\n";
echo "<li>Add ?domain=<DOMAIN> to the URL to use alternative domain</li>\n";
echo "</ul><b>Session Clustering Session ID Format</b>: Master - Port - Backup - Port - Version - SessionID<br>\n";
echo "</p>\n";

$session_info = ini_get_all("session");

//### Session Log data ###
echo "<h2>Session Running Counter - ";
if (isset($_SESSION['counter'])) {
	echo ++$_SESSION['counter'] . "</h2>\n";
} else {
	$_SESSION['counter'] = 1; // initiate session data
	echo "<span style='color: #b00'>1 (New Session or Session had expired)</span></h2>\n"; // no session data exist
}



if (!isset($_SESSION['log']))
	$_SESSION['log'] = "";

$server_host = $_SERVER['SERVER_NAME'];
$server_ip = $_SERVER['SERVER_ADDR'];
$localMachine = getHostName();
$localIP = getHostByName(getHostName());

// Timer Logging
$session_timer = "";
if (isset($_GET['time'])) // insert time measurements
	$session_timer = "[" . sprintf("%.5f", $time_seconds) . " sec.] ";

$_SESSION['log'] .= $session_timer
		. $_SESSION['counter'] . ". <b>" . date("Y-m-d H:i:s") . '</b> '
		. "sent to <b>{$server_host}[{$server_ip}]]</b> "
		. "and handled by server <b>{$localMachine}[{$localIP}]</b>, "
		. "Session '<b>" . session_id() . "</b>'<br>\n";

echo "<div style=\"border: 1px solid maroon; font-size: small; font-family: courier new, lucinda, monospace\">\n";
echo $_SESSION['log'];
echo "</div>";

// Translating
$session_translate = "";
$translate = explode("-", session_id());

// non SC, don't translate
if (count($translate) < 6) {
	echo "<br><b>Note: </b>Session Clustering not activated, format is not parsed and there is no second table with translated Zend SC format.<br>\n";
}
 else {
	echo "<h2>Session Log with Zend Translated</h2>\n";
	if (!isset($_SESSION['log_t']))
		$_SESSION['log_t'] = "";

	$tr_hex = array();
	foreach ($translate as $v)
		$tr_hex[] = str_pad(dechex(0XBABAB0BA ^ hexdec($v)), 8, "0",
				STR_PAD_LEFT);

	//Master IP (HA and non-HA)
	$ip_arr = array();
	$ip = str_split($tr_hex[0], 2);
	foreach ($ip as $v)
		$ip_arr[] = hexdec($v);
	$session_translate .= implode(".", $ip_arr);
	$session_translate .= "-" . hexdec($tr_hex[1]);

	//DEBUG
	//echo "<br>\n***{$tr_hex[2]}***<br>\n";
	//echo "<br>\n***{$translate[2]}***<br>\n";

	// non-HA format check
	if (count($translate) > 6) {
		$session_translate .= "-00000000-00000000-00000000-00000000";
		$session_translate .= "-" . $translate[6];
	}
	// HA mode
 else {

		// no Backup IP - standalone or cluster issues	
		if ($translate[2] == "00000000") {
			$session_translate .= "-00000000-00000000";
			$session_translate .= "-" . $translate[4] . "-" . $translate[5];
		}
		// Backup IP exists for HA
 else {
			$ip_arr = array();
			$ip = str_split($tr_hex[2], 2);
			foreach ($ip as $v)
				$ip_arr[] = hexdec($v);
			$session_translate .= "-" . implode(".", $ip_arr) . "-"
					. hexdec($tr_hex[3]);
			$session_translate .= "-" . $translate[4] . "-" . $translate[5];
		}

	} // else - HA Mode

	$_SESSION['log_t'] .= $session_timer . $_SESSION['counter'] . ". <b>" . date("Y-m-d H:i:s")
			. "</b> sent to '<b>" . $server_host . "[" . $server_ip
			. "]</b>', Session '<b>" . $session_translate . "</b>'<br>\n";

	echo "<div style=\"border: 1px solid blue; font-size: small; font-family: courier new, lucinda, monospace\">\n";
	echo $_SESSION['log_t'];
	echo "</div>";
}
echo "</p>\n";

//### Session Important Config ###
echo "<h2>Following PHP active config affects Session Clustering</h2>\n";
echo "<p><table cellpadding=\"2\" cellspacing=\"0\" border=\"1\" style=\"font-family: sans-serif\">";
$important_directives = array(
    "session.cookie_domain" => "empty - normally not needed",
    "session.cookie_lifetime" => "0 - no limit on the browser side",
    "session.cookie_path" => "/ - not set if not needed",
    "session.name" => "PHPSESSID",
    "session.save_handler" => "Zend cluster or PHP files",
    "session.serialize_handler" => "php");
foreach ($session_info as $x => $v) {
    if (array_key_exists($x, $important_directives)) {
        $lv = $v["local_value"];
        echo "<tr><th align=\"left\">$x</th><td>" . (($lv != "") ? $lv : "empty")
        . "</td><td>Default - " . $important_directives[$x]
        . "</td></tr>\n";
    }
}
echo "</table></p>";

//### Session Configuration ###
echo "<p><h2>Complete Session Configuration in your PHP</h2>\n";
echo "<table border=\"1\" cellspacing=\"0\" cellpadding=\"2\"><tr><th align=\"left\">php.ini Directive</th><th align=\"left\">Global Value</th><th align=\"left\">Local Value</th><th align=\"left\">Access</th></tr>\n";
foreach ($session_info as $x => $v) {
	echo "<tr>";
	echo "<th align=\"left\">$x</th>";
	foreach ($v as $i) {
		echo "<td>" . (($i != "") ? $i : "empty") . "</td>\n";
	}
	echo "</tr>\n";
}
echo "</table></p>\n";
echo "</body>\n</html>"
//var_dump($session_info);
?>