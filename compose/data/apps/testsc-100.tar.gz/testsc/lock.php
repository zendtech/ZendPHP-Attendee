<?php

if (isset($_GET['lock4'])) {
    session_start();
    sleep($_GET['lock4']);
    $_SESSION['contents'] = "<strong>Locked for " . $_GET['lock4'] . " :</strong> " . session_id() . "<br>\n" . $_SESSION['contents'];
    echo "<strong>" . session_id() . "</strong> :<br>\n";
    echo $_SESSION['contents'];
    if ($_GET['setCookie']){
        $params = session_get_cookie_params();
        setcookie(session_name(), session_id(), 2000000000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
    }
    exit();
}
if (isset($_GET['norm'])) {
    session_start();
    sleep(1);
    $_SESSION['contents'] = "<strong>Normal :</strong> " . session_id() . "<br>\n" . $_SESSION['contents'];
    echo "<strong>" . session_id() . "</strong> :<br>\n";
    echo $_SESSION['contents'];
    if ($_GET['setCookie']){
        $params = session_get_cookie_params();
        setcookie(session_name(), session_id(), 2000000000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
    }
    exit();
}
if (isset($_GET['reset'])) {
    session_start();
    $sessID = session_id();
    if ($_GET['reset']){
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
    }
    session_destroy();
    echo "Session <strong>$sessID</strong> destroyed";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<script>
function loadAJAX(divId,reqParam)
{
//document.getElementById(divId).innerHTML='<image src=ticktock.png>';
document.getElementById(divId).innerHTML='<div class="loading">&nbsp;</div>';
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById(divId).innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET", window.location.href + reqParam,true);
xmlhttp.timeout=300000;
xmlhttp.send();
}

function lockReq(moreParam)
{
	reqParam='?lock4=' + document.getElementById('secSlow').value
	loadAJAX('slow',reqParam + moreParam)
}

</script>
<style>

.loading:after {
	border-width: 0 2px 0 0;
	border-style: solid;
	border-color: rgba(256, 0, 0, .5);
	border-radius: 50%;
	display: inline-block;
	vertical-align: top;
	height: 60px;
	left: 50%;
	margin: 30px 0 0 -30px;
	position: relative;
	top: 50%;
	width: 60px;

	content: "";

	animation: spin 0.5s infinite linear;
	-webkit-animation: spin 0.5s infinite linear;
}
@keyframes spin {
	from { transform: rotate(0deg); }
	to { transform: rotate(360deg); }
}
@-webkit-keyframes spin {
	from { -webkit-transform: rotate(0deg); }
	to { -webkit-transform: rotate(360deg); }
}


</style>
</head>
<body style='background-color: white'>

	<div style="border: 1px solid #900; border-radius: 5px; padding: 5px">
		Lock the session for <input id="secSlow" value="70" style="width: 30px; text-align: center;"> seconds&nbsp;&nbsp;&nbsp;
		<button onclick="lockReq('');">Go</button>&nbsp;&nbsp;&nbsp;&nbsp;
		<button onclick="lockReq('&setCookie=1');">Go with a cookie</button>
		<br>
		<div id="slow" style="height: 150px; overflow: auto;">&nbsp;</div>
	</div>
	<br>
	<div style="border: 1px solid #090; border-radius: 5px; padding: 5px">
		Start a normal session (with 1 sec.delay)&nbsp;&nbsp;&nbsp;
		<button onclick="loadAJAX('normal','?norm=1');">Go</button>&nbsp;&nbsp;&nbsp;&nbsp;
		<button onclick="loadAJAX('normal','?norm=1&setCookie=1');">Go with a cookie</button>
		<br>
		<div id="normal" style="height: 150px; overflow: auto;">&nbsp;</div>
	</div>
	<br>
	<div style="border: 1px solid #009; border-radius: 5px; padding: 5px">
		&nbsp;&nbsp;&nbsp;<button onclick="loadAJAX('operations','?reset=0');">Destroy session</button>
		&nbsp;&nbsp;&nbsp;&nbsp;
		<button onclick="loadAJAX('operations','?reset=1');">Destroy session and remove cookie</button>
		<br>
		<div id="operations" style="height: 50px; overflow: auto;">&nbsp;</div>
	</div>

</body>
</html>